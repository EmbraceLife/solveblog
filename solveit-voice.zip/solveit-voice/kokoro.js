// ═══════════════════════════════════════════════════════════════════════
// Voice Widget Module: Kokoro TTS — The Premium Voice (via Replicate)
//
// DESIGN: Calls Replicate's Kokoro-82M model directly from the browser
// using the HTTP API. No Python backend needed — the Replicate API key
// is stored in chrome.storage and passed via data-* attribute.
//
// FLOW: Detect stable response → POST to Replicate → poll prediction
// → get audio URL → play in <audio> element.
//
// When Kokoro is ON, it intercepts speechSynthesis.speak() to block
// browser TTS, ensuring only one voice plays at a time.
//
// CHINESE: Chinese text falls back to browser TTS (built-in voices
// like Ting-Ting, Huihui, Google 普通话) since the Replicate model
// lacks pypinyin.
// ═══════════════════════════════════════════════════════════════════════

if (!window.__voiceKokoroInit) {
window.__voiceKokoroInit = true;

(function() {
const V = window._voice;
if (!V) { console.error('[Kokoro] No voice widget'); return; }
if (window._kokoroCleanup) window._kokoroCleanup();

const log = V.log;
const kokoroCb = { checked: false };

const getReplicateKey = () => document.documentElement.dataset.solveitReplicateKey || '';
const getOpenrouterKey = () => document.documentElement.dataset.solveitOpenrouterKey || '';


const KOKORO_VERSION = 'jaaari/kokoro-82m:f559560eb822dc509045f3921a1921234918b91739db4bf3daab2169b71c7a13';
// const KOKORO_VERSION = 'alphanumericuser/kokoro-82m:89b6fa84e4fa2dd6bd3a96be3e1f12827a3516c9fda8fddbac7a0be131c9a6f5';

//const CHTTS_VERSION = 'e1100x/chattts:f84864bcadf646ecb5024d4539b2d46078b3e5f64549cff0a00026dc596929ad';

const COSYVOICE_VERSION = 'chenxwh/cosyvoice2-0.5b:669b1cd618f2747d2237350e868f5c313f3b548fc803ca4e57adfaba778b042d';

// const COSYVOICE_VERSION = 'jichengdu/cosyvoice:4106862b8e948847f2d7e1513eb1b03e7bd07333343dda94c83cf78d82eb3f1d';




// ───────────── Chinese text detection ─────────────
const CHINESE_RE = /[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/;
// ──────────────────────────────────────────────────

// --- Audio Container DOM ---
const ac = document.createElement('div');
ac.id = 'kokoro-audio-container';
const statusRow = document.createElement('div');
statusRow.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:2px 0';
const statusText = document.createElement('span');
statusText.className = 'kokoro-status';
const closeBtn = document.createElement('button');
closeBtn.textContent = '✕';
closeBtn.className = 'kokoro-close';
statusRow.appendChild(statusText);
statusRow.appendChild(closeBtn);
ac.appendChild(statusRow);

const audio = document.createElement('audio');
audio.controls = true;
audio.style.cssText = 'width:100%;height:48px;border-radius:8px';
ac.appendChild(audio);
(V.widget || document.body).appendChild(ac);

function resetAudio() {
    audio.pause(); audio.removeAttribute('src'); audio.load();
    ac.style.display = 'none'; V.speaking = false;
    if (V.toggleCb.checked) V.safeStart(V.CFG.restartMs);
}
closeBtn.onclick = resetAudio;

audio.onplay = () => { V.speaking = true; };
audio.onended = () => {
    statusText.textContent = '✅ Done — click ▶ to replay';
    V.speaking = false;
    if (V.toggleCb.checked) V.safeStart(V.CFG.restartMs);
};

// --- Block browser TTS when Kokoro ON ---
const origSpeak = speechSynthesis.speak.bind(speechSynthesis);
speechSynthesis.speak = function(utt) {
    if (kokoroCb.checked) { log('Kokoro: blocking browser TTS'); V.ttsStopBtn.style.display = 'none'; return; }
    return origSpeak(utt);
};

const origTtsEnd = V.ttsEnd;
V.ttsEnd = () => {
    if (kokoroCb.checked && !audio.paused && !audio.ended) return;
    origTtsEnd();
};

// --- Bridge helper: send fetch request via content.js → background.js ---
let _reqCounter = 0;
function replicateFetch(url, opts = {}) {
    return new Promise((resolve, reject) => {
        const requestId = 'rf-' + (++_reqCounter) + '-' + Date.now();
        function handler(e) {
            if (e.source !== window || e.data?.type !== 'replicate-fetch-response') return;
            if (e.data.requestId !== requestId) return;
            window.removeEventListener('message', handler);
            if (e.data.ok) resolve(e.data.data);
            else reject(new Error(e.data.error || 'Replicate fetch failed: ' + e.data.status));
        }
        window.addEventListener('message', handler);
        window.postMessage({
            type: 'replicate-fetch', requestId, url,
            method: opts.method || 'GET',
            headers: opts.headers || {},
            body: opts.body || undefined
        }, '*');
        setTimeout(() => { window.removeEventListener('message', handler); reject(new Error('Replicate fetch timeout')); }, 120000);
    });
}

// --- Replicate API: Create prediction and poll until done ---
// async function replicatePredict(text, voice = 'bf_emma', speed = 0.9) {
async function replicatePredict(text, voice, speed = 0.9) {
    if (!voice) voice = CHINESE_RE.test(text) ? 'zf_xiaobei' : 'bf_emma';

    const apiKey = getReplicateKey();
    if (!apiKey) throw new Error('No Replicate API key — set it in extension popup');
    const versionHash = KOKORO_VERSION.split(':')[1];
    const prediction = await replicateFetch('https://api.replicate.com/v1/predictions', {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + apiKey,
            'Content-Type': 'application/json',
            'Prefer': 'wait'
        },
        body: JSON.stringify({
            version: versionHash,
            // input: { text: text.slice(0, 10000), voice, speed }
            input: { text: text.slice(0, 10000), voice, speed, text_language: CHINESE_RE.test(text) ? 'zh' : 'en' }

        })
    });
    let result = prediction;
    let attempts = 0;
    while (result.status !== 'succeeded' && result.status !== 'failed' && attempts < 60) {
        await new Promise(r => setTimeout(r, 1000));
        result = await replicateFetch('https://api.replicate.com/v1/predictions/' + result.id, {
            headers: { 'Authorization': 'Bearer ' + apiKey }
        });
        attempts++;
    }
    if (result.status === 'failed') throw new Error('Kokoro failed: ' + (result.error || 'unknown'));
    if (result.status !== 'succeeded') throw new Error('Kokoro timed out');
    return result.output;
}


async function openrouterKokoro(text) {
    const apiKey = getOpenrouterKey();
    if (!apiKey) throw new Error('No OpenRouter API key — set it in extension popup');
    const resp = await fetch('https://openrouter.ai/api/v1/audio/speech', {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + apiKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            model: 'hexgrad/kokoro-82m',
            input: text.slice(0, 10000),
            voice: 'zf_xiaoyi',
            response_format: 'mp3'
        })
    });
    if (!resp.ok) {
        const err = await resp.text().catch(() => resp.statusText);
        throw new Error('OpenRouter TTS failed: ' + err);
    }
    const blob = await resp.blob();
    return URL.createObjectURL(blob);
}



async function cosyvoicePredict(text) {
    const apiKey = getReplicateKey();
    if (!apiKey) throw new Error('No Replicate API key');
    const versionHash = COSYVOICE_VERSION.split(':')[1];
    const prediction = await replicateFetch('https://api.replicate.com/v1/predictions', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + apiKey, 'Content-Type': 'application/json', 'Prefer': 'wait' },
        body: JSON.stringify({
            version: versionHash,
            input: {
                tts_text: text.slice(0, 10000),
                source_audio: 'https://replicate.delivery/pbxt/MgbBQRAKfZkuc9EcspUou25Uxfdgc3xWS43kvqIla8eWBsaQ/zero_shot_prompt.wav',
                source_transcript: '希望你以后能够做得比我还好哟！',
                task: 'zero-shot voice clone'
            }

        })
    });
    let result = prediction, attempts = 0;
    while (result.status !== 'succeeded' && result.status !== 'failed' && attempts < 60) {
        await new Promise(r => setTimeout(r, 1000));
        result = await replicateFetch('https://api.replicate.com/v1/predictions/' + result.id, { headers: { 'Authorization': 'Bearer ' + apiKey } });
        attempts++;
    }
    if (result.status === 'failed') throw new Error('CosyVoice failed: ' + (result.error || 'unknown'));
    if (result.status !== 'succeeded') throw new Error('CosyVoice timed out');
    return result.output;
}



// ┌──────────────────────────────────────────────────────────────────┐
// │  ▼▼▼  REPLACED kokoroSpeak — Chinese goes to browser TTS  ▼▼▼   │
// └──────────────────────────────────────────────────────────────────┘
async function kokoroSpeak(text) {
    if (!text || !text.trim()) return;
    if (V.isWakeActive && V.isWakeActive()) { log('Kokoro suppressed: wake active'); return; }
    if (V._tabHidden) { log('Kokoro suppressed: tab hidden'); return; }

    // ── Chinese text → browser TTS (Replicate model lacks pypinyin) ──
    if (CHINESE_RE.test(text)) {
        
    }
    // ── English text → Replicate Kokoro ──

    statusText.textContent = CHINESE_RE.test(text) ? '⏳ Generating Chinese audio...' : '⏳ Generating audio...';


    ac.style.display = 'block';
    V.speaking = true;
    if (V.resetWakeState) V.resetWakeState();

    try {
        const isZh = CHINESE_RE.test(text);
        const audioUrl = isZh ? await openrouterKokoro(text) : await replicatePredict(text);



        if (!audioUrl) throw new Error('No audio URL returned');
        log('Kokoro: audio ready', audioUrl);
        statusText.textContent = '🔊 Playing...';
        audio.src = audioUrl;
        audio.play().catch(e => { log('Kokoro play error:', e); statusText.textContent = '❌ Play failed'; });
    } catch(e) {
        log('Kokoro error:', e.message);
        statusText.textContent = '❌ ' + e.message;
        V.speaking = false;
    }
}
// ┌──────────────────────────────────────────────────────────────────┐
// │  ▲▲▲  END OF REPLACED kokoroSpeak  ▲▲▲                          │
// └──────────────────────────────────────────────────────────────────┘

// --- Toggle in gear dropdown ---
const dd = document.querySelector('#voice-gear-dropdown');
if (dd) {
    const row = document.createElement('div'); row.className = 'v-switch-row';
    const txt = document.createElement('span'); txt.textContent = '🎵 Kokoro TTS';
    const track = document.createElement('span'); track.className = 'v-track';
    const thumb = document.createElement('span'); thumb.className = 'v-thumb';
    function render() {
        track.style.background = kokoroCb.checked ? '#ff9f43' : '#555';
        if (kokoroCb.checked) { thumb.style.right='1px'; thumb.style.left='auto'; thumb.style.background='#fff'; }
        else { thumb.style.left='1px'; thumb.style.right='auto'; thumb.style.background='#888'; }
    }
    render();
    track.appendChild(thumb); row.appendChild(txt); row.appendChild(track);
    row.onclick = () => {
        kokoroCb.checked = !kokoroCb.checked; render();
        if (!kokoroCb.checked) resetAudio();
        log('Kokoro:', kokoroCb.checked ? 'ON' : 'OFF');
    };
    dd.appendChild(row);
}

// --- Watch for prompt responses ---
const skipTags = new Set(['PRE', 'CODE', 'DETAILS']);
function getText(proseEl) {
    if (V._extractProseText) return V._extractProseText(proseEl);
    const tw = document.createTreeWalker(proseEl, NodeFilter.SHOW_TEXT, {
        acceptNode: n => {
            let p = n.parentElement;
            while (p && p !== proseEl) { if (skipTags.has(p.tagName) || p.classList.contains('cm-editor')) return NodeFilter.FILTER_REJECT; p = p.parentElement; }
            return NodeFilter.FILTER_ACCEPT;
        }
    });
    let t = ''; while (tw.nextNode()) t += tw.currentNode.textContent;
    return t.replace(/[\0-\x08\x0b\x0c\x0e-\x1f]/g, '').trim().slice(0, 10000);
}

let poll = null, safety = null;
function clearWatch() { if (poll) clearInterval(poll); if (safety) clearTimeout(safety); poll = safety = null; }
V.clearKokoroWatch = clearWatch;

function watchResp(id) {
    clearWatch();
    let last = '', stable = 0, threshold = 12;
    poll = setInterval(() => {
        const el = document.querySelector('#' + id + '-o .prose');
        if (!el) return;
        if (threshold < 20 && el.querySelector('details')) threshold = 20;
        const t = getText(el);
        if (!t.length) return;
        if (t === last) { if (++stable >= threshold) { clearWatch(); kokoroSpeak(t); } }
        else { last = t; stable = 0; }
    }, 500);
    safety = setTimeout(clearWatch, 300000);
}

const wsListen = (e) => {
    if (!V.userActive) return;
    if (V._tabHidden) { log('Kokoro watcher blocked: tab hidden'); return; }
    if (!kokoroCb.checked) return;
    const html = e.detail.message;
    if (!html.includes('data-mtype="prompt"')) return;
    const isVoice = html.includes('🎤');
    if (isVoice && !V.ttsCb.checked) return;
    if (!isVoice && !V.ttsManualCb.checked) return;
    const m = html.match(/id="(_[a-f0-9]+)"/);
    if (!m) return;
    log('Kokoro: watching', m[1]);
    watchResp(m[1]);
};
document.body.addEventListener('htmx:wsAfterMessage', wsListen);

// --- Play button for selected completed prompts ---
const playBtn = document.createElement('button');
playBtn.textContent = '▶';
playBtn.title = 'Play audio for this response';
playBtn.style.cssText = 'display:none;font-size:1.2em;border:none;background:rgba(255,159,67,0.3);' +
  'border-radius:8px;padding:4px 10px;color:#ff9f43;cursor:pointer;margin-left:4px';
playBtn.onmouseenter = () => playBtn.style.background = 'rgba(255,159,67,0.5)';
playBtn.onmouseleave = () => playBtn.style.background = 'rgba(255,159,67,0.3)';

const widget = document.getElementById('voice-widget');
if (widget) {
    const statusEl = widget.querySelector('.v-status');
    if (statusEl) widget.insertBefore(playBtn, statusEl);
}

let selectedPromptId = null;

function checkSelectedPrompt() {
    const sel = document.querySelector('[data-sm="primary"]');
    if (!sel) { playBtn.style.display = 'none'; selectedPromptId = null; return; }
    const msgId = sel.id;
    const card = document.querySelector('#' + msgId + '-i');
    const mtype = card ? card.getAttribute('data-mtype') : sel.getAttribute('data-mtype');
    const isNote = mtype === 'note';
    if (mtype !== 'prompt' && !isNote) { playBtn.style.display = 'none'; selectedPromptId = null; return; }
    const contentEl = isNote
        ? document.querySelector('#' + msgId + '-i .prose')
        : document.querySelector('#' + msgId + '-o .prose');
    if (!contentEl || !getText(contentEl).trim()) { playBtn.style.display = 'none'; selectedPromptId = null; return; }
    selectedPromptId = msgId;
    playBtn.style.display = 'inline';
}

playBtn.onclick = () => {
    if (!selectedPromptId) return;
    const card = document.querySelector('#' + selectedPromptId + '-i');
    const mtype = card ? card.getAttribute('data-mtype') : '';
    const contentEl = mtype === 'note'
        ? document.querySelector('#' + selectedPromptId + '-i .prose')
        : document.querySelector('#' + selectedPromptId + '-o .prose');
    if (!contentEl) return;
    const text = getText(contentEl);
    if (!text.trim()) return;
    log('Play selected prompt:', selectedPromptId, text.length, 'chars');
    if (kokoroCb.checked) { kokoroSpeak(text); }
    else if (V._speakText) { V._speakText(text); }
};

const playObserver = new MutationObserver(checkSelectedPrompt);
playObserver.observe(document.body, { attributes: true, attributeFilter: ['data-sm'], subtree: true });

// --- Cleanup ---
window._kokoroCleanup = () => {
    speechSynthesis.speak = origSpeak;
    V.ttsEnd = origTtsEnd;
    document.body.removeEventListener('htmx:wsAfterMessage', wsListen);
    playObserver.disconnect();
    clearWatch(); resetAudio(); ac.remove(); playBtn.remove();
    window.__voiceKokoroInit = false;
};

log('✅ Kokoro TTS loaded (EN via Replicate, CN via browser). Toggle 🎵 in gear menu.');
})();

}
