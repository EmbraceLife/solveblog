// ═══════════════════════════════════════════════════════════════════════
// Voice Widget Module: Kokoro TTS — The Premium Voice (via Replicate)
//
// DESIGN: Calls Replicate's Kokoro-82M model directly from the browser
// using the HTTP API. No Python backend needed — the Replicate API key
// is stored in chrome.storage and passed via data-* attribute.
//
// FLOW: Detect stable response → POST to Replicate → poll prediction
// → get audio URL → play in <audio> element.
//
// When Kokoro is ON, it intercepts speechSynthesis.speak() to block
// browser TTS, ensuring only one voice plays at a time.
//
// CHINESE: Chinese text falls back to browser TTS (built-in voices
// like Ting-Ting, Huihui, Google 普通话) since the Replicate model
// lacks pypinyin.
// ═══════════════════════════════════════════════════════════════════════

if (!window.__voiceKokoroInit) {
window.__voiceKokoroInit = true;

(function() {
const V = window._voice;
if (!V) { console.error('[Kokoro] No voice widget'); return; }
if (window._kokoroCleanup) window._kokoroCleanup();

const log = V.log;
const kokoroCb = { checked: false };

const getReplicateKey = () => document.documentElement.dataset.solveitReplicateKey || '';
const getOpenrouterKey = () => document.documentElement.dataset.solveitOpenrouterKey || '';

// ── IndexedDB Audio Cache (borrowed from SolBlock 01_app.py player) ──
const CACHE_DB = 'kokoro_tts_cache', CACHE_STORE = 'blobs';
function openCacheDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(CACHE_DB, 1);
        req.onupgradeneeded = e => { if (!e.target.result.objectStoreNames.contains(CACHE_STORE)) e.target.result.createObjectStore(CACHE_STORE); };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}
function cacheGet(key) {
    return openCacheDB().then(db => new Promise((resolve, reject) => {
        const tx = db.transaction(CACHE_STORE, 'readonly');
        const r = tx.objectStore(CACHE_STORE).get(key);
        r.onsuccess = () => resolve(r.result);
        r.onerror = () => reject(r.error);
    }));
}
function cacheSet(key, val) {
    return openCacheDB().then(db => new Promise((resolve, reject) => {
        const tx = db.transaction(CACHE_STORE, 'readwrite');
        tx.objectStore(CACHE_STORE).put(val, key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
    }));
}
function cacheKey(text, voice) {
    let h = 5381, s = voice + '|' + text;
    for (let i = 0; i < s.length; i++) { h = ((h << 5) + h) + s.charCodeAt(i); h |= 0; }
    return 'kokoro_' + h.toString(36) + '_len_' + s.length;
}
function getCacheTotalSize() {
    return openCacheDB().then(db => new Promise((resolve, reject) => {
        const tx = db.transaction(CACHE_STORE, 'readonly');
        const cursor = tx.objectStore(CACHE_STORE).openCursor();
        let total = 0, count = 0;
        cursor.onsuccess = e => {
            const c = e.target.result;
            if (c) { if (c.value instanceof Uint8Array) total += c.value.byteLength; count++; c.continue(); }
            else resolve({ bytes: total, count });
        };
        cursor.onerror = () => reject(cursor.error);
    }));
}
function clearAllTtsCache() {
    return openCacheDB().then(db => new Promise((resolve, reject) => {
        const tx = db.transaction(CACHE_STORE, 'readwrite');
        tx.objectStore(CACHE_STORE).clear();
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
    }));
}
function formatBytes(bytes) {
    if (!isFinite(bytes) || bytes < 0) return '0 B';
    if (bytes < 1024) return Math.round(bytes) + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

// ── Decode raw audio bytes to a seekable WAV blob ──
// TTS-generated MP3s often lack VBR/Xing headers, so <audio>.currentTime
// seek fails silently. Decoding to PCM WAV guarantees seekability.
function audioBufferToWav(buffer) {
    const numCh = buffer.numberOfChannels, sr = buffer.sampleRate;
    const dataLen = buffer.length * numCh * 2;
    const ab = new ArrayBuffer(44 + dataLen);
    const v = new DataView(ab);
    const ws = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    ws(0,'RIFF'); v.setUint32(4, 36+dataLen, true); ws(8,'WAVE');
    ws(12,'fmt '); v.setUint32(16,16,true); v.setUint16(20,1,true);
    v.setUint16(22,numCh,true); v.setUint32(24,sr,true);
    v.setUint32(28,sr*numCh*2,true); v.setUint16(32,numCh*2,true);
    v.setUint16(34,16,true);
    ws(36,'data'); v.setUint32(40,dataLen,true);
    const chans = [];
    for (let c = 0; c < numCh; c++) chans.push(buffer.getChannelData(c));
    let off = 44;
    for (let i = 0; i < buffer.length; i++) {
        for (let c = 0; c < numCh; c++) {
            const s = Math.max(-1, Math.min(1, chans[c][i]));
            v.setInt16(off, s < 0 ? s*0x8000 : s*0x7FFF, true); off += 2;
        }
    }
    return new Blob([ab], { type: 'audio/wav' });
}

function decodeToWavBlob(bytes) {
    return new Promise((resolve, reject) => {
        new Blob([bytes], {type:'audio/mpeg'}).arrayBuffer().then(buf => {
            const AC = window.AudioContext || window.webkitAudioContext;
            const ctx = new AC();
            ctx.decodeAudioData(buf.slice(0),
                ab => { ctx.close(); resolve({blob: audioBufferToWav(ab), duration: ab.duration}); },
                err => { ctx.close(); reject(err); }
            );
        }).catch(reject);
    });
}

// Play raw audio bytes (MP3/WAV/anything) via a decoded WAV blob so the
// progress bar can seek. Falls back to raw bytes if decoding fails.
function playAudioBytes(bytes, statusMsg) {
    decodeToWavBlob(bytes).then(({blob}) => {
        audio.src = URL.createObjectURL(blob);
        statusText.textContent = statusMsg || '🔊 Playing...';
        audio.play().catch(e => { log('Kokoro play error:', e); statusText.textContent = '❌ Play failed'; });
    }).catch(err => {
        log('Kokoro: WAV decode failed, falling back to raw:', err.message);
        audio.src = URL.createObjectURL(new Blob([bytes], {type:'audio/mpeg'}));
        statusText.textContent = statusMsg || '🔊 Playing...';
        audio.play().catch(e => { log('Kokoro play error:', e); statusText.textContent = '❌ Play failed'; });
    });
}


const KOKORO_VERSION = 'jaaari/kokoro-82m:f559560eb822dc509045f3921a1921234918b91739db4bf3daab2169b71c7a13';
// const KOKORO_VERSION = 'alphanumericuser/kokoro-82m:89b6fa84e4fa2dd6bd3a96be3e1f12827a3516c9fda8fddbac7a0be131c9a6f5';

//const CHTTS_VERSION = 'e1100x/chattts:f84864bcadf646ecb5024d4539b2d46078b3e5f64549cff0a00026dc596929ad';

const COSYVOICE_VERSION = 'chenxwh/cosyvoice2-0.5b:669b1cd618f2747d2237350e868f5c313f3b548fc803ca4e57adfaba778b042d';

// const COSYVOICE_VERSION = 'jichengdu/cosyvoice:4106862b8e948847f2d7e1513eb1b03e7bd07333343dda94c83cf78d82eb3f1d';




// ───────────── Chinese text detection ─────────────
const CHINESE_RE = /[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/;
// ──────────────────────────────────────────────────

// --- Audio Container DOM ---
const ac = document.createElement('div');
ac.id = 'kokoro-audio-container';
ac.style.display = 'none';
const statusRow = document.createElement('div');
statusRow.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:2px 0';
const statusText = document.createElement('span');
statusText.className = 'kokoro-status';
const closeBtn = document.createElement('button');
closeBtn.textContent = '✕';
closeBtn.className = 'kokoro-close';
statusRow.appendChild(statusText);
statusRow.appendChild(closeBtn);
ac.appendChild(statusRow);

// ── Custom player: progress bar + time + controls ──
const playerDiv = document.createElement('div');
playerDiv.style.cssText = 'display:none;';
playerDiv.className = 'kokoro-player';

// Progress bar (seek slider) — drag to any position
const progressBar = document.createElement('input');
progressBar.type = 'range';
progressBar.min = '0';
progressBar.max = '100';
progressBar.value = '0';
progressBar.step = '0.1';
progressBar.className = 'kokoro-progress';
progressBar.title = 'Drag to seek — click any position to jump';
progressBar.style.cssText = 'width:100%;height:6px;-webkit-appearance:none;appearance:none;background:rgba(255,255,255,0.12);border-radius:3px;outline:none;cursor:pointer;margin:4px 0;';
playerDiv.appendChild(progressBar);

// Time display: current / duration
const timeRow = document.createElement('div');
timeRow.style.cssText = 'display:flex;justify-content:space-between;align-items:center;font-size:0.75em;color:#999;font-family:monospace;margin:2px 0;';
const currentTimeEl = document.createElement('span');
currentTimeEl.textContent = '0:00';
const durationTimeEl = document.createElement('span');
durationTimeEl.textContent = '0:00';
timeRow.appendChild(currentTimeEl);
timeRow.appendChild(durationTimeEl);
playerDiv.appendChild(timeRow);

// Control buttons: Play/Pause | Stop | Replay
const controlsRow = document.createElement('div');
controlsRow.style.cssText = 'display:flex;align-items:center;gap:8px;margin-top:4px;';

const playPauseBtn = document.createElement('button');
playPauseBtn.textContent = '▶';
playPauseBtn.title = 'Play / Pause';
playPauseBtn.style.cssText = 'background:rgba(255,159,67,0.18);border:1px solid rgba(255,159,67,0.4);color:#ff9f43;border-radius:6px;padding:4px 14px;cursor:pointer;font-size:1em;min-width:40px;transition:background 0.15s;';
playPauseBtn.onmouseenter = () => playPauseBtn.style.background = 'rgba(255,159,67,0.32)';
playPauseBtn.onmouseleave = () => playPauseBtn.style.background = 'rgba(255,159,67,0.18)';

const stopBtn = document.createElement('button');
stopBtn.textContent = '⏹';
stopBtn.title = 'Stop (reset to beginning)';
stopBtn.style.cssText = 'background:rgba(255,107,107,0.12);border:1px solid rgba(255,107,107,0.3);color:#ff6b6b;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:0.9em;transition:background 0.15s;';
stopBtn.onmouseenter = () => stopBtn.style.background = 'rgba(255,107,107,0.22)';
stopBtn.onmouseleave = () => stopBtn.style.background = 'rgba(255,107,107,0.12)';

const replayBtn = document.createElement('button');
replayBtn.textContent = '🔄';
replayBtn.title = 'Replay from beginning';
replayBtn.style.cssText = 'background:rgba(107,197,255,0.12);border:1px solid rgba(107,197,255,0.3);color:#6bc5ff;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:0.9em;transition:background 0.15s;';
replayBtn.onmouseenter = () => replayBtn.style.background = 'rgba(107,197,255,0.22)';
replayBtn.onmouseleave = () => replayBtn.style.background = 'rgba(107,197,255,0.12)';

controlsRow.appendChild(playPauseBtn);
controlsRow.appendChild(stopBtn);
controlsRow.appendChild(replayBtn);
playerDiv.appendChild(controlsRow);

ac.appendChild(playerDiv);

// ── Cache info bar: size, item count, remaining storage, clear button ──
const cacheDiv = document.createElement('div');
cacheDiv.className = 'kokoro-cache-info';
cacheDiv.style.cssText = 'display:none;margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.1);font-size:0.72em;color:#999;';
const cacheRow1 = document.createElement('div');
cacheRow1.style.cssText = 'display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap;';
const cacheSizeEl = document.createElement('span');
cacheSizeEl.textContent = '📦 Cache: --';
const cacheRemainingEl = document.createElement('span');
cacheRemainingEl.textContent = '💾 Free: --';
cacheRow1.appendChild(cacheSizeEl);
cacheRow1.appendChild(cacheRemainingEl);
cacheDiv.appendChild(cacheRow1);
const cacheRow2 = document.createElement('div');
cacheRow2.style.cssText = 'display:flex;justify-content:flex-end;';
const clearCacheBtn = document.createElement('button');
clearCacheBtn.textContent = '🗑 Clear Cache';
clearCacheBtn.title = 'Delete all cached TTS audio files';
clearCacheBtn.style.cssText = 'background:rgba(255,107,107,0.12);border:1px solid rgba(255,107,107,0.3);color:#ff6b6b;border-radius:4px;padding:2px 8px;cursor:pointer;font-size:0.95em;transition:background 0.15s;';
clearCacheBtn.onmouseenter = () => clearCacheBtn.style.background = 'rgba(255,107,107,0.25)';
clearCacheBtn.onmouseleave = () => clearCacheBtn.style.background = 'rgba(255,107,107,0.12)';
cacheRow2.appendChild(clearCacheBtn);
cacheDiv.appendChild(cacheRow2);
ac.appendChild(cacheDiv);

// Hidden audio element — native controls removed, custom UI used instead
const audio = document.createElement('audio');
audio.style.cssText = 'display:none;';
ac.appendChild(audio);

// Range slider thumb CSS (cross-browser)
const _pbStyle = document.createElement('style');
_pbStyle.textContent = '.kokoro-progress::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:14px;height:14px;border-radius:50%;background:#ff9f43;cursor:grab;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,0.4);transition:transform 0.1s;}.kokoro-progress::-webkit-slider-thumb:active{cursor:grabbing;transform:scale(1.2);}.kokoro-progress::-moz-range-thumb{width:14px;height:14px;border-radius:50%;background:#ff9f43;cursor:grab;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,0.4);}.kokoro-progress::-moz-range-thumb:active{cursor:grabbing;transform:scale(1.2);}.kokoro-progress::-moz-range-track{height:6px;background:rgba(255,255,255,0.12);border-radius:3px;}';
document.head.appendChild(_pbStyle);

(V.widget || document.body).appendChild(ac);

// ── Player helpers ──
function fmtTime(sec) {
    if (!isFinite(sec) || isNaN(sec)) return '0:00';
    const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
}
function showPlayer() { playerDiv.style.display = 'block'; }
function resetPlayerUI() {
    progressBar.value = 0;
    currentTimeEl.textContent = '0:00';
    durationTimeEl.textContent = '0:00';
    playPauseBtn.textContent = '▶';
}
let isSeeking = false;

function updateProgress() {
    if (!audio.duration || isNaN(audio.duration)) return;
    if (!isSeeking) progressBar.value = (audio.currentTime / audio.duration) * 100;
    currentTimeEl.textContent = fmtTime(audio.currentTime);
}
function updateDuration() {
    if (audio.duration && isFinite(audio.duration)) durationTimeEl.textContent = fmtTime(audio.duration);
}

// ── Seek: drag slider to any position (borrowed from SolBlock player) ──
progressBar.addEventListener('input', () => {
    isSeeking = true;
    if (audio.duration && isFinite(audio.duration)) {
        currentTimeEl.textContent = fmtTime((progressBar.value / 100) * audio.duration);
    }
});
progressBar.addEventListener('change', () => {
    if (audio.duration && isFinite(audio.duration)) {
        audio.currentTime = (progressBar.value / 100) * audio.duration;
    }
    isSeeking = false;
});

progressBar.addEventListener('mousedown', () => { isSeeking = true; });
progressBar.addEventListener('touchstart', () => { isSeeking = true; }, { passive: true });

// ── Control buttons ──
playPauseBtn.onclick = () => {
    if (audio.paused) audio.play().catch(e => log('Play error:', e));
    else audio.pause();
};
stopBtn.onclick = () => {
    audio.pause();
    audio.currentTime = 0;
    resetPlayerUI();
    statusText.textContent = '⏹ Stopped';
    V.speaking = false;
    if (V.toggleCb.checked) V.safeStart(V.CFG.restartMs);
};
replayBtn.onclick = () => {
    audio.currentTime = 0;
    audio.play().catch(e => log('Replay error:', e));
};

// ── Audio event handlers ──
audio.ontimeupdate = updateProgress;
audio.onloadedmetadata = updateDuration;
audio.onplay = () => {
    V.speaking = true;
    playPauseBtn.textContent = '⏸';
    statusText.textContent = '🔊 Playing...';
};
audio.onpause = () => {
    if (!audio.ended && audio.currentTime > 0) {
        playPauseBtn.textContent = '▶';
        statusText.textContent = '⏸ Paused';
    }
};
audio.onended = () => {
    statusText.textContent = '✅ Done — click ▶ or 🔄 to replay';
    playPauseBtn.textContent = '▶';
    V.speaking = false;
    if (V.toggleCb.checked) V.safeStart(V.CFG.restartMs);
};

function resetAudio() {
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
    resetPlayerUI();
    playerDiv.style.display = 'none';
    cacheDiv.style.display = 'none';
    ac.style.display = 'none';
    V.speaking = false;
    if (V.toggleCb.checked) V.safeStart(V.CFG.restartMs);
}
closeBtn.onclick = resetAudio;

// ── Cache display: refresh size + remaining storage ──
async function refreshCacheDisplay() {
    try {
        const { bytes, count } = await getCacheTotalSize();
        cacheSizeEl.textContent = '📦 Cache: ' + formatBytes(bytes) + ' (' + count + ' item' + (count !== 1 ? 's' : '') + ')';
    } catch(e) { cacheSizeEl.textContent = '📦 Cache: unavailable'; }
    if (navigator.storage && navigator.storage.estimate) {
        try {
            const est = await navigator.storage.estimate();
            const remaining = Math.max(0, est.quota - est.usage);
            cacheRemainingEl.textContent = '💾 Free: ' + formatBytes(remaining) + ' / ' + formatBytes(est.quota);
        } catch(e) { cacheRemainingEl.textContent = '💾 Free: unavailable'; }
    } else {
        cacheRemainingEl.textContent = '💾 Free: N/A';
    }
}
function showCacheInfo() {
    cacheDiv.style.display = 'block';
    refreshCacheDisplay();
}
clearCacheBtn.onclick = async () => {
    if (!confirm('Clear ALL cached TTS audio?\n\nNext playback will re-generate from API (may cost credits).')) return;
    try {
        await clearAllTtsCache();
        log('Kokoro cache cleared');
        statusText.textContent = '🗑 Cache cleared';
        refreshCacheDisplay();
    } catch(e) {
        log('Cache clear error:', e);
        statusText.textContent = '❌ Cache clear failed';
    }
};

// --- Block browser TTS when Kokoro ON ---
const origSpeak = speechSynthesis.speak.bind(speechSynthesis);
speechSynthesis.speak = function(utt) {
    if (kokoroCb.checked) { log('Kokoro: blocking browser TTS'); V.ttsStopBtn.style.display = 'none'; return; }
    return origSpeak(utt);
};

const origTtsEnd = V.ttsEnd;
V.ttsEnd = () => {
    if (kokoroCb.checked && !audio.paused && !audio.ended) return;
    origTtsEnd();
};

// --- Bridge helper: send fetch request via content.js → background.js ---
let _reqCounter = 0;
function replicateFetch(url, opts = {}) {
    return new Promise((resolve, reject) => {
        const requestId = 'rf-' + (++_reqCounter) + '-' + Date.now();
        function handler(e) {
            if (e.source !== window || e.data?.type !== 'replicate-fetch-response') return;
            if (e.data.requestId !== requestId) return;
            window.removeEventListener('message', handler);
            if (e.data.ok) resolve(e.data.data);
            else reject(new Error(e.data.error || 'Replicate fetch failed: ' + e.data.status));
        }
        window.addEventListener('message', handler);
        window.postMessage({
            type: 'replicate-fetch', requestId, url,
            method: opts.method || 'GET',
            headers: opts.headers || {},
            body: opts.body || undefined
        }, '*');
        setTimeout(() => { window.removeEventListener('message', handler); reject(new Error('Replicate fetch timeout')); }, 120000);
    });
}

// --- Replicate API: Create prediction and poll until done ---
// async function replicatePredict(text, voice = 'bf_emma', speed = 0.9) {
async function replicatePredict(text, voice, speed = 0.9) {
    if (!voice) voice = CHINESE_RE.test(text) ? 'zf_xiaobei' : 'bf_emma';

    const apiKey = getReplicateKey();
    if (!apiKey) throw new Error('No Replicate API key — set it in extension popup');
    const versionHash = KOKORO_VERSION.split(':')[1];
    const prediction = await replicateFetch('https://api.replicate.com/v1/predictions', {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + apiKey,
            'Content-Type': 'application/json',
            'Prefer': 'wait'
        },
        body: JSON.stringify({
            version: versionHash,
            // input: { text: text.slice(0, 10000), voice, speed }
            input: { text: text.slice(0, 10000), voice, speed, text_language: CHINESE_RE.test(text) ? 'zh' : 'en' }

        })
    });
    let result = prediction;
    let attempts = 0;
    while (result.status !== 'succeeded' && result.status !== 'failed' && attempts < 60) {
        await new Promise(r => setTimeout(r, 1000));
        result = await replicateFetch('https://api.replicate.com/v1/predictions/' + result.id, {
            headers: { 'Authorization': 'Bearer ' + apiKey }
        });
        attempts++;
    }
    if (result.status === 'failed') throw new Error('Kokoro failed: ' + (result.error || 'unknown'));
    if (result.status !== 'succeeded') throw new Error('Kokoro timed out');
    return result.output;
}


async function openrouterKokoro(text) {
    const apiKey = getOpenrouterKey();
    if (!apiKey) throw new Error('No OpenRouter API key — set it in extension popup');
    const resp = await fetch('https://openrouter.ai/api/v1/audio/speech', {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + apiKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            model: 'hexgrad/kokoro-82m',
            input: text.slice(0, 10000),
            voice: 'zf_xiaoyi',
            response_format: 'mp3'
        })
    });
    if (!resp.ok) {
        const err = await resp.text().catch(() => resp.statusText);
        throw new Error('OpenRouter TTS failed: ' + err);
    }
    const blob = await resp.blob();
    return blob;  // blob returned so kokoroSpeak can cache bytes + create URL
}



async function cosyvoicePredict(text) {
    const apiKey = getReplicateKey();
    if (!apiKey) throw new Error('No Replicate API key');
    const versionHash = COSYVOICE_VERSION.split(':')[1];
    const prediction = await replicateFetch('https://api.replicate.com/v1/predictions', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + apiKey, 'Content-Type': 'application/json', 'Prefer': 'wait' },
        body: JSON.stringify({
            version: versionHash,
            input: {
                tts_text: text.slice(0, 10000),
                source_audio: 'https://replicate.delivery/pbxt/MgbBQRAKfZkuc9EcspUou25Uxfdgc3xWS43kvqIla8eWBsaQ/zero_shot_prompt.wav',
                source_transcript: '希望你以后能够做得比我还好哟！',
                task: 'zero-shot voice clone'
            }

        })
    });
    let result = prediction, attempts = 0;
    while (result.status !== 'succeeded' && result.status !== 'failed' && attempts < 60) {
        await new Promise(r => setTimeout(r, 1000));
        result = await replicateFetch('https://api.replicate.com/v1/predictions/' + result.id, { headers: { 'Authorization': 'Bearer ' + apiKey } });
        attempts++;
    }
    if (result.status === 'failed') throw new Error('CosyVoice failed: ' + (result.error || 'unknown'));
    if (result.status !== 'succeeded') throw new Error('CosyVoice timed out');
    return result.output;
}



// ┌──────────────────────────────────────────────────────────────────┐
// │  ▼▼▼  REPLACED kokoroSpeak — Chinese goes to browser TTS  ▼▼▼   │
// └──────────────────────────────────────────────────────────────────┘
async function kokoroSpeak(text) {
    if (!text || !text.trim()) return;
    if (V.isWakeActive && V.isWakeActive()) { log('Kokoro suppressed: wake active'); return; }
    if (V._tabHidden) { log('Kokoro suppressed: tab hidden'); return; }

    const isZh = CHINESE_RE.test(text);
    const voice = isZh ? 'zf_xiaoyi' : 'bf_emma';
    const key = cacheKey(text, voice);

    // ── 1. Check IndexedDB cache first ──
    const cached = await cacheGet(key).catch(() => null);
    if (cached && cached.byteLength > 0) {
        log('📦 Kokoro cache hit', formatBytes(cached.byteLength));
        ac.style.display = 'block';
        V.speaking = true;
        if (V.resetWakeState) V.resetWakeState();
        
        resetPlayerUI(); showPlayer(); showCacheInfo();
        playAudioBytes(cached, '📦 Playing from cache...');
        return;

    }

    // ── 2. Cache miss — generate from API ──
    statusText.textContent = isZh ? '⏳ Generating Chinese audio...' : '⏳ Generating audio...';
    ac.style.display = 'block';
    V.speaking = true;
    if (V.resetWakeState) V.resetWakeState();

    try {
        let bytes, mimeType;
        if (isZh) {
            const blob = await openrouterKokoro(text);
            bytes = new Uint8Array(await blob.arrayBuffer());
            mimeType = 'audio/mpeg';
        } else {
            const url = await replicatePredict(text);
            if (!url) throw new Error('No audio URL returned');
            try {
                const resp = await fetch(url);
                if (!resp.ok) throw new Error('HTTP ' + resp.status);
                bytes = new Uint8Array(await resp.arrayBuffer());
                mimeType = 'audio/wav';
            } catch(e) {

                log('Kokoro: fetch failed, downloading direct URL for decode:', e.message);
                try {
                    const directResp = await fetch(url);
                    if (!directResp.ok) throw new Error('HTTP ' + directResp.status);
                    const directBytes = new Uint8Array(await directResp.arrayBuffer());
                    resetPlayerUI(); showPlayer(); showCacheInfo();
                    playAudioBytes(directBytes, '🔊 Playing...');
                } catch(e2) {
                    log('Kokoro: direct URL download also failed:', e2.message);
                    statusText.textContent = '❌ Play failed';
                }
                return;

            }
        }

        cacheSet(key, bytes).catch(e => log('Kokoro cache set error:', e));
        log('💾 Kokoro cached', formatBytes(bytes.byteLength));
        resetPlayerUI(); showPlayer(); showCacheInfo();
        playAudioBytes(bytes, '🔊 Playing...');

    } catch(e) {
        log('Kokoro error:', e.message);
        statusText.textContent = '❌ ' + e.message;
        V.speaking = false;
    }
}
// ┌──────────────────────────────────────────────────────────────────┐
// │  ▲▲▲  END OF REPLACED kokoroSpeak  ▲▲▲                          │
// └──────────────────────────────────────────────────────────────────┘

// --- Toggle in gear dropdown ---
const dd = document.querySelector('#voice-gear-dropdown');
if (dd) {
    const row = document.createElement('div'); row.className = 'v-switch-row';
    const txt = document.createElement('span'); txt.textContent = '🎵 Kokoro TTS';
    const track = document.createElement('span'); track.className = 'v-track';
    const thumb = document.createElement('span'); thumb.className = 'v-thumb';
    function render() {
        track.style.background = kokoroCb.checked ? '#ff9f43' : '#555';
        if (kokoroCb.checked) { thumb.style.right='1px'; thumb.style.left='auto'; thumb.style.background='#fff'; }
        else { thumb.style.left='1px'; thumb.style.right='auto'; thumb.style.background='#888'; }
    }
    render();
    track.appendChild(thumb); row.appendChild(txt); row.appendChild(track);
    row.onclick = () => {
        kokoroCb.checked = !kokoroCb.checked; render();
        if (!kokoroCb.checked) resetAudio();
        log('Kokoro:', kokoroCb.checked ? 'ON' : 'OFF');
    };
    dd.appendChild(row);

    // ── Cache info button — view storage usage without playing audio ──
    const cacheRow = document.createElement('div');
    cacheRow.className = 'v-switch-row';
    cacheRow.style.cssText = 'cursor:pointer;';
    const cacheTxt = document.createElement('span');
    cacheTxt.textContent = '📦 TTS Cache';
    cacheTxt.style.cssText = 'flex:1;';
    const cacheBadge = document.createElement('span');
    cacheBadge.textContent = '…';
    cacheBadge.style.cssText = 'font-size:0.75em;color:#888;';
    cacheRow.appendChild(cacheTxt);
    cacheRow.appendChild(cacheBadge);
    cacheRow.onclick = async () => {
        if (ac.style.display === 'block' && !V.speaking) {
            // Toggle off if only showing cache
            resetAudio();
            cacheBadge.textContent = '…';
            return;
        }
        ac.style.display = 'block';
        playerDiv.style.display = 'none';
        showCacheInfo();
        try {
            const { bytes } = await getCacheTotalSize();
            cacheBadge.textContent = formatBytes(bytes);
        } catch(e) { cacheBadge.textContent = 'err'; }
    };
    dd.appendChild(cacheRow);
}

// --- Watch for prompt responses ---
const skipTags = new Set(['PRE', 'CODE', 'DETAILS']);
function getText(proseEl) {
    if (V._extractProseText) return V._extractProseText(proseEl);
    const tw = document.createTreeWalker(proseEl, NodeFilter.SHOW_TEXT, {
        acceptNode: n => {
            let p = n.parentElement;
            while (p && p !== proseEl) { if (skipTags.has(p.tagName) || p.classList.contains('cm-editor')) return NodeFilter.FILTER_REJECT; p = p.parentElement; }
            return NodeFilter.FILTER_ACCEPT;
        }
    });
    let t = ''; while (tw.nextNode()) t += tw.currentNode.textContent;
    return t.replace(/[\0-\x08\x0b\x0c\x0e-\x1f]/g, '').trim().slice(0, 10000);
}

let poll = null, safety = null;
function clearWatch() { if (poll) clearInterval(poll); if (safety) clearTimeout(safety); poll = safety = null; }
V.clearKokoroWatch = clearWatch;

function watchResp(id) {
    clearWatch();
    let last = '', stable = 0, threshold = 12;
    poll = setInterval(() => {
        const el = document.querySelector('#' + id + '-o .prose');
        if (!el) return;
        if (threshold < 20 && el.querySelector('details')) threshold = 20;
        const t = getText(el);
        if (!t.length) return;
        if (t === last) { if (++stable >= threshold) { clearWatch(); kokoroSpeak(t); } }
        else { last = t; stable = 0; }
    }, 500);
    safety = setTimeout(clearWatch, 300000);
}

const wsListen = (e) => {
    if (!V.userActive) return;
    if (V._tabHidden) { log('Kokoro watcher blocked: tab hidden'); return; }
    if (!kokoroCb.checked) return;
    const html = e.detail.message;
    if (!html.includes('data-mtype="prompt"')) return;
    const isVoice = html.includes('🎤');
    if (isVoice && !V.ttsCb.checked) return;
    if (!isVoice && !V.ttsManualCb.checked) return;
    const m = html.match(/id="(_[a-f0-9]+)"/);
    if (!m) return;
    log('Kokoro: watching', m[1]);
    watchResp(m[1]);
};
document.body.addEventListener('htmx:wsAfterMessage', wsListen);

// --- Play button for selected completed prompts ---
const playBtn = document.createElement('button');
playBtn.textContent = '▶';
playBtn.title = 'Play audio for this response';
playBtn.style.cssText = 'display:none;font-size:1.2em;border:none;background:rgba(255,159,67,0.3);' +
  'border-radius:8px;padding:4px 10px;color:#ff9f43;cursor:pointer;margin-left:4px';
playBtn.onmouseenter = () => playBtn.style.background = 'rgba(255,159,67,0.5)';
playBtn.onmouseleave = () => playBtn.style.background = 'rgba(255,159,67,0.3)';

const widget = document.getElementById('voice-widget');
if (widget) {
    const statusEl = widget.querySelector('.v-status');
    if (statusEl) widget.insertBefore(playBtn, statusEl);
}

let selectedPromptId = null;

function checkSelectedPrompt() {
    const sel = document.querySelector('[data-sm="primary"]');
    if (!sel) { playBtn.style.display = 'none'; selectedPromptId = null; return; }
    const msgId = sel.id;
    const card = document.querySelector('#' + msgId + '-i');
    const mtype = card ? card.getAttribute('data-mtype') : sel.getAttribute('data-mtype');
    const isNote = mtype === 'note';
    if (mtype !== 'prompt' && !isNote) { playBtn.style.display = 'none'; selectedPromptId = null; return; }
    const contentEl = isNote
        ? document.querySelector('#' + msgId + '-i .prose')
        : document.querySelector('#' + msgId + '-o .prose');
    if (!contentEl || !getText(contentEl).trim()) { playBtn.style.display = 'none'; selectedPromptId = null; return; }
    selectedPromptId = msgId;
    playBtn.style.display = 'inline';
}

playBtn.onclick = () => {
    if (!selectedPromptId) return;
    const card = document.querySelector('#' + selectedPromptId + '-i');
    const mtype = card ? card.getAttribute('data-mtype') : '';
    const contentEl = mtype === 'note'
        ? document.querySelector('#' + selectedPromptId + '-i .prose')
        : document.querySelector('#' + selectedPromptId + '-o .prose');
    if (!contentEl) return;
    const text = getText(contentEl);
    if (!text.trim()) return;
    log('Play selected prompt:', selectedPromptId, text.length, 'chars');
    if (kokoroCb.checked) { kokoroSpeak(text); }
    else if (V._speakText) { V._speakText(text); }
};

const playObserver = new MutationObserver(checkSelectedPrompt);
playObserver.observe(document.body, { attributes: true, attributeFilter: ['data-sm'], subtree: true });

// --- Cleanup ---
window._kokoroCleanup = () => {
    speechSynthesis.speak = origSpeak;
    V.ttsEnd = origTtsEnd;
    document.body.removeEventListener('htmx:wsAfterMessage', wsListen);
    playObserver.disconnect();
    clearWatch(); resetAudio(); ac.remove(); playBtn.remove();
    window.__voiceKokoroInit = false;
};

log('✅ Kokoro TTS loaded (EN via Replicate, CN via browser). Toggle 🎵 in gear menu.');
})();

}
