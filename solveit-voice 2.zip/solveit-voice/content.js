// ═══════════════════════════════════════════════════════════════
// SolveIt Voice — Content Script Loader
//
// DESIGN: Inject voice modules into the page's MAIN world in order.
// Each module attaches to window._voice (the shared bridge).
// Follows the minimap extension pattern: content.js loads scripts,
// scripts self-heal via watchdog and AbortController cleanup.
//
// API KEYS: Read from chrome.storage, passed to page via data-*
// attributes on <html>. Scripts read keys at call-time via getters.
// ═══════════════════════════════════════════════════════════════

(async function () {
  const log = (...args) => console.log('[sv-loader]', ...args);

  log('content script running, url:', location.href);

  // Only inject on dialog pages — skip dashboard, terminal, folder views
  if (!location.pathname.startsWith('/dialog_')) {
    log('not a dialog page, skipping voice injection');
    return;
  }

  const alive = () => !!chrome.runtime?.id;

  function loadScript(path) {
    return new Promise((resolve, reject) => {
      if (!alive()) return reject(new Error('extension context invalidated'));
      const s = document.createElement('script');
      s.src = chrome.runtime.getURL(path);
      s.dataset.solveitVoice = '1';
      s.onload = () => { log('loaded:', path); resolve(); };
      s.onerror = () => reject(new Error('failed to load ' + path));
      document.head.appendChild(s);
    });
  }

  // Pass API keys from chrome.storage to page via data-* attributes.
  const keys = await chrome.storage.local.get({
    porcupineKey: '',
    replicateKey: '',
    openrouterKey: '',
    enabled: true
  });

  if (!keys.enabled) {
    log('extension disabled via popup, skipping');
    return;
  }

  const dname = new URLSearchParams(location.search).get('name')
      || document.getElementById('dlg_name')?.value;
  if (!dname) { log('no dname found, skipping injection'); return; }
  document.documentElement.dataset.solveitDname = dname;

  document.documentElement.dataset.solveitPorcupineKey = keys.porcupineKey || '';
  document.documentElement.dataset.solveitReplicateKey = keys.replicateKey || '';
  document.documentElement.dataset.solveitOpenrouterKey = keys.openrouterKey || '';

  // Listen for key updates from popup (while page is open)
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.porcupineKey) {
      document.documentElement.dataset.solveitPorcupineKey = changes.porcupineKey.newValue || '';
    }
    if (changes.replicateKey) {
      document.documentElement.dataset.solveitReplicateKey = changes.replicateKey.newValue || '';
    }
    if (changes.openrouterKey) {
      document.documentElement.dataset.solveitOpenrouterKey = changes.openrouterKey.newValue || '';
    }
    if (changes.enabled && !changes.enabled.newValue) {
      log('extension disabled, cleaning up');
      if (window._voiceCleanup) window._voiceCleanup();
    }
  });

  // --- Bridge: MAIN world → content script → background service worker ---
  window.addEventListener('message', async (e) => {
    if (e.source !== window || e.data?.type !== 'replicate-fetch') return;
    const { url, method, headers, body, requestId } = e.data;
    try {
      const resp = await chrome.runtime.sendMessage({
        type: 'replicate-fetch', url, method, headers, body
      });
      window.postMessage({ type: 'replicate-fetch-response', requestId, ...resp }, '*');
    } catch (err) {
      window.postMessage({ type: 'replicate-fetch-response', requestId, ok: false, error: err.message }, '*');
    }
  });

  // --- Bridge: Gist API ---
  window.addEventListener('message', async (e) => {
    if (e.source !== window || e.data?.type !== 'gist-fetch') return;
    const { url, method, headers, body, requestId } = e.data;
    try {
      const resp = await chrome.runtime.sendMessage({
        type: 'gist-fetch', url, method, headers, body
      });
      window.postMessage({ type: 'gist-fetch-response', requestId, ...resp }, '*');
    } catch (err) {
      window.postMessage({ type: 'gist-fetch-response', requestId, ok: false, error: err.message }, '*');
    }
  });

  // Guard: don't double-inject if scripts already loaded
  if (document.querySelector('script[data-solveit-voice]')) {
    log('scripts already loaded, skipping');
    return;
  }

  const modules = [
    'widget.js',
    'state-machine.js',
    'send.js',
    'tts.js',
    'kokoro.js',
    'porcupine.js',
    'save-toggle.js',
    'draggable.js',
    'visibility.js',
  ];

  try {
    for (const mod of modules) await loadScript(mod);
    log('all modules loaded');
  } catch (e) {
    log('module load error:', e.message);
  }
})();
